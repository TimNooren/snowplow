# -*- coding: utf-8 -*-

from __future__ import print_function

import base64
import boto3
import os

print('Loading function')
firehose = boto3.client('firehose')

FIREHOSE_STREAM_NAME = os.environ.get("firehose_stream_name")


def lambda_handler(event, context):

    for record in event['Records']:
        # Kinesis data is base64 encoded so decode here
        payload = base64.b64decode(record['kinesis']['data'])

        # write to the Firehose Stream
        print(payload)
        firehose.put_record_batch(
            DeliveryStreamName=FIREHOSE_STREAM_NAME,
            Records=[{'Data': payload + '\n'}]  # added a newline or else everything returns on a single line
        )

    return 'Successfully processed {} records.'.format(len(event['Records']))

