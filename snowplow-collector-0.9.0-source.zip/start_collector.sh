#!/bin/ash

sed -i 's/\(name = \).*/\1\"'"$COOKIE_NAME"'\"/' snowplow-collector.config
sed -i 's/\(region: \).*/\1\"'"$AWS_REGION"'\"/' snowplow-collector.config
sed -i 's/\(good: \).*/\1\"'"$STREAM_GOOD"'\"/' snowplow-collector.config
sed -i 's/\(bad: \).*/\1\"'"$STREAM_BAD"'\"/' snowplow-collector.config

/usr/bin/java -jar /snowplow-stream-collector-0.9.0 --config /snowplow-collector.config