#!/bin/ash

sed -i 's/\(region: \).*/\1\"'"$AWS_REGION"'\"/' snowplow-enricher.config
sed -i 's/\(enriched: \).*/\1\"'"$STREAM_GOOD"'\"/' snowplow-enricher.config
sed -i 's/\(bad: \).*/\1\"'"$STREAM_BAD"'\"/' snowplow-enricher.config
sed -i 's/\(raw: \).*/\1\"'"$INPUT_STREAM"'\"/' snowplow-enricher.config
sed -i 's/\(app-name: \).*/\1\"'"$DYNAMODB_NAME"'\"/' snowplow-enricher.config

/usr/bin/java -jar /snowplow-stream-enrich-0.10.0 --config /snowplow-enricher.config --resolver file:resolver.json