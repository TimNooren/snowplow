# -*- coding: utf-8 -*-

from __future__ import print_function

import base64
import os
from datetime import datetime
import redis

print('Loading function')

REDIS_ENDPOINT = os.environ.get('REDIS_ENDPOINT')
REDIS_PORT = os.environ.get('REDIS_PORT')


def handler(event, context):
    """
    This handler sends data which contains page_views and product_skus to Redis
    Kinesis base64 objects are decoded into strings and split into a list.
    Args:
        event: event with multiple Kinesis rows (json blob)
        context: not used in script

    Returns: # of processed rows.

    """
    # print("Received event: " + json.dumps(event, indent=2))

    pipe = redis.StrictRedis(host=REDIS_ENDPOINT, port=REDIS_PORT).pipeline()

    for record in event['Records']:
        # Kinesis data is base64 encoded so decode here
        payload = base64.b64decode(record['kinesis']['data'])
        print(payload)

        try:
            split_tab = [payload.split('\t')]
            user_id, event_type, url = process_event(split_tab[0])
            if url is not None:
                print(user_id, event_type, url)
                if event_type == 'page_view':
                    print('This event is a valid page_view')
                    pipe.lrem(user_id + '/RECENTNEW', 0, str(url))
                    pipe.lpush(user_id + '/RECENTNEW', str(url))
                    pipe.ltrim(user_id + '/RECENTNEW', 0, 20)
                    pipe.expire(user_id + '/RECENTNEW', 604800)
                    pipe.lpush(user_id + '/TSNEW', datetime.now())
                    pipe.execute()
                    print('Redis lpush statement is successful.')

        except Exception, error:
            print(error)
            print('Redis lpush statement failed.')

    return 'Successfully processed {} records.'.format(len(event['Records']))


def process_event(event):
    """
    This function parses the Snowplow event string data and only sends the data we need
    for the Redis cluster.
    Args:
        event: full event (String)

    Returns: snowplow data: user_id (String), event_type (page_view), product_sku (int)

    """
    if event[12] in ['null', 'undefined', '']:
        user_id = event[15]
    else:
        user_id = event[12]
    url = event[29]
    event_type = event[5]

    return user_id, event_type, url

